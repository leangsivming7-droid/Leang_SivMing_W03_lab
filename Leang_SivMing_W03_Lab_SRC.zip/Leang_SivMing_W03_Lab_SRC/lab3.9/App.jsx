
import './App.css'
import { useState } from "react";

function App() {
  const [list, setList] = useState(["Eat", "Sleep", "Code"]);

  return (
    <ul>
      {list.map((item, index) => (
        <li key={index}>{item}</li>
      ))}
    </ul>
  );
}

export default App;
