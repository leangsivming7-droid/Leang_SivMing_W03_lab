import './App.css'
function App() {
  const [count, setCount] = useState(0)
  return (
    <div className='app'>
      <h1>My task list</h1>
      <input type="text" placeholder="Enter a task..." />
      <button>Add Task</button>
    </div>
  )
}
export default App
