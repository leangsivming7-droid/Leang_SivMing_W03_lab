import viteLogo from '/vite.svg'
import './App.css'
  // 1. Define the TodoItem function above App
function TodoItem() {
  return <li>A task needs to be done</li>;
}

function App() {
  return (
    <div>
      <ul>
        {/* 2. Call TodoItem four times inside the ul */}
        <TodoItem />
        <TodoItem />
        <TodoItem />
        <TodoItem />
      </ul>
    </div>
  );
}
export default App;