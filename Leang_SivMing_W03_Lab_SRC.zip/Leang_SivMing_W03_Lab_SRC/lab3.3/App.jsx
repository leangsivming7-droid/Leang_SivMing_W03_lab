import { useState } from 'react'; 
import './App.css';
function App() {
  const [count, setCount] = useState(0);
  const tasks = ["Learn JSX", "Create Components", "Master State"];
  return (
    <div>
      <h1>My Task List</h1>
      <ul>
        <li>{tasks[0]}</li>
        <li>{tasks[1]}</li>
        <li>{tasks[2]}</li>
      </ul>
    </div>
  );
}

export default App;