
import './App.css'
function App() {
  const [text, setText] = useState("");

  return (
    <div>
      <input
        type="text"
        value={text} // Syncs input value with state
        onChange={(e) => setText(e.target.value)} // Updates state on user input
      />
      <p>You are typing: {text}</p>
    </div>
  );
}

export default App
