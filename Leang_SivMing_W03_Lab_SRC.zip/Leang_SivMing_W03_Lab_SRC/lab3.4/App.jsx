
import viteLogo from '/vite.svg'
import './App.css'
    function App() {
  const tasks = ["Learn JSX", "Create Components", "Master State", "Build Apps"];
  return (
    <div>
      <h1>My Task List</h1>
      <p>{tasks.length}</p>
      <ul>
        <li>{tasks[0]}</li>
        <li>{tasks[1]}</li>
        <li>{tasks[2]}</li>
        <li>{tasks[3]}</li>
      </ul>
    </div>
  );
}
  

export default App
